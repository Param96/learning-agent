import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Learning Agent - Personal Learning Dashboard",
  description: "AI-Powered Personal Learning Agent",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">{children}</body>
    </html>
  );
}